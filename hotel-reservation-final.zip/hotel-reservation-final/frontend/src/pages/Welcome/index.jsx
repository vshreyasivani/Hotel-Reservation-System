import React from "react";
import "./index.css";

const Welcome = () => {

  return (
    <div className="image">
      <div className="welcome"> WELCOME </div>
      <div className="name"> TO TRIVASHI'S PARADISE</div>
    </div>
  );
};

export default Welcome;
